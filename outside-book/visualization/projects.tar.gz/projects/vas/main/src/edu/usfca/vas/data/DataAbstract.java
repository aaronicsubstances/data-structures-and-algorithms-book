/*

[The "BSD licence"]
Copyright (c) 2004 Jean Bovet
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package edu.usfca.vas.data;

import edu.usfca.xj.appkit.document.XJDataXML;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.util.ArrayList;
import java.util.List;

public abstract class DataAbstract extends XJDataXML {

    protected List wrappers = new ArrayList();
    protected int currentWrapperIndex = -1;

    public DataAbstract() {
    }

    public DataWrapperAbstract getDataWrapperAtIndex(int index) {
        return (DataWrapperAbstract)wrappers.get(index);
    }

    public void removeDataWrapperAtIndex(int index) {
        wrappers.remove(index);
    }

    public void addWrapper(DataWrapperAbstract wrapper) {
        wrappers.add(wrapper);
    }
    
    public List getWrappers() {
        return wrappers;
    }

    public void setCurrentWrapperIndex(int index) {
        currentWrapperIndex = index;
    }

    public int getCurrentWrapperIndex() {
        return currentWrapperIndex;
    }

    public void clear() {
        wrappers.clear();
    }

    public void customReadData(XMLDecoder d) {
        wrappers = (List)d.readObject();
        currentWrapperIndex = ((Integer)d.readObject()).intValue();
    }

    public void customWriteData(XMLEncoder e) {
        e.writeObject(wrappers);
        e.writeObject(new Integer(currentWrapperIndex));
    }

}
